<!DOCTYPE html>
<html lang="en-US">
<head>
<title>notifications</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />




<!-- jQuery -->
<script type="text/javascript" src="pagesMenu/src/libs/jquery/jquery.js"></script>

<!-- SmartMenus jQuery plugin -->
<script type="text/javascript" src="pagesMenu/jquery.smartmenus.js"></script>



<script type="text/javascript">
	$(function() {
		$('#main-menu').smartmenus({
			subMenusSubOffsetX: 1,
			subMenusSubOffsetY: -8
		});
	});
</script>


<link rel="stylesheet" type="text/css" href="alpages.css">
<link rel="stylesheet" type="text/css" href="pmenu.css">

<link href="pagesMenu/src/css/sm-core-css.css" rel="stylesheet" type="text/css" />

<link href="pagesMenu/src/css/sm-blue/sm-blue.css" rel="stylesheet" type="text/css" />

<link href="pageMenu/src/libs/demo-assets/demo.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="java_Script1/Mytheme.min.css">

</head>
<body>
<header width="100%;"height="100%;">
<div id="h_log">
<img id="logo" src="FWMA_PIC/fwm.png"></img>
<div id="h_con">
<h1>Notifications</h1>
</div>
</div>
</header>

<nav id="main-nav" role="navigation">
  
  <ul id="main-menu" class="sm sm-blue">
<!--<div id="nav">
  <div id="nav_wrapper">/-->
    
      <li><a href="index.html">Welcome</a></li>
	  <li>
       <a href="videos.html">Videos</a></li>
	       <li><a href="conferance.html">Conferance</a></li>
		   <li><a href="bible_college.html">Bible College</a></li>
		   <li><a href="itinerary.html">Itinerary</a></li>
		   <li><a href="prayer_request.php">Prayer Request</a></li>
		   <li><a href="donate.html">Donate</a></li>
	     
	   </li>
	   
     </ul>
   <!-- </div>
</div>/-->

</nav>
<section>
   <div id="my_pics">

              <div id="bishops"><img src="FWMA_PIC/bishop.jpg" width="100%" height="30%"
			  ></img></div>
               
      
  </div>
  </section>

<div id="note">
	<p maxlength="300" cols="60%" rows="10%" name="text" required>
		<?php
		$filename ='faith world admin potal/notifications.txt';
		$handle =fopen($filename, 'r');
		
		
		
		echo fread( $handle,1000);

		?>
		
	</p>
</div>
    <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="https://www.facebook.com/BishopDr.B.Manjoro/"><img src="FWMA_PIC/fb.gif" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="https://twitter.com/intent/follow?original_referer=http%3A%2F%2Fbishopmanjoro.org%2Ffwm%2Findex.php&ref_src=twsrc%5Etfw&screen_name=bishopmanjoro&tw_p=followbutton">  <img src="FWMA_PIC/twt.gif" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="https://www.youtube.com/results?search_query=bishop+manjoro"> <img src="FWMA_PIC/email.gif" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
</body>

</html>