<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Audio Players</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />




<!-- jQuery -->
<script type="text/javascript" src="pagesMenu/src/libs/jquery/jquery.js"></script>

<!-- SmartMenus jQuery plugin -->
<script type="text/javascript" src="pagesMenu/jquery.smartmenus.js"></script>


<script type="text/javascript">
	$(function() {
		$('#main-menu').smartmenus({
			subMenusSubOffsetX: 1,
			subMenusSubOffsetY: -8
		});
	});
</script>


<link rel="stylesheet" type="text/css" href="alpages.css">


<link href="pagesMenu/src/css/sm-core-css.css" rel="stylesheet" type="text/css" />

<link href="pagesMenu/src/css/sm-blue/sm-blue.css" rel="stylesheet" type="text/css" />

<link href="pageMenu/src/libs/demo-assets/demo.css" rel="stylesheet" type="text/css" />
<link rel ="stylesheet" type="text/css" href="formzDesign.css">
</head>
<body>
<header width="100%;"height="100%;">
<div id="h_log">
<img id="logo" src="FWMA_PIC/fwm.png"></img>
<div id="h_con">
<h1>Play</h1>
</div>
</div>
</header>

<nav id="main-nav" role="navigation">
  
  <ul id="main-menu" class="sm sm-blue">
<!--<div id="nav">
  <div id="nav_wrapper">/-->
    
      <li><a href="index.html">Welcome</a>
	  <ul>
	       <li><a href="conferance.html">Conferance</a></li>
		   <li><a href="bible college.html">Bible College</a></li>
		   <li><a href="itinerary.html">Itinerary</a></li>
		   <li><a href="prayer_request.html">Prayer Request</a></li>
		   <li><a href="donate.html">Donate</a></li>
	     </ul>
	   </li><li>
	  
       <a href="about_us.html">About Us</a>
	   <ul>
	       <li><a href="about_bishop.html">Bishop Manjoro</a></li>
		   <li><a href="about_bishop;s family.html">Bishop's Family</a></li>
		   <li><a href="about_work and achivements.html">Work's And Achivements</a></li>
	     </ul>
	   </li><li>
       <a href="videos.html">Videos</a></li>
     </ul>
   <!-- </div>
</div>/-->

</nav>
<br>
		<?php
		$directory="faith world admin potal/audio/audio_uploads";
		if($handle = opendir($directory.'/')){
			echo'<b>Audio</b>'.'<br><br>';
			
			while($file = readdir($handle)){
				if($file!='.' && $file!='..'){
					echo'<video  controls width="55%" height="30%" title="'.$file.'" src="'.$directory.'/'.$file.'">'. $file.'
					<source src="'.$directory.'/'.$file.'.mp3"  type="audio/mp3">

    <object width="640" height="480" type="application/x-shockwave-flash" data="player.swf">
        
   title="No direct video playback capabilities, so please download the video below">
    </object>
	
	
					</video><br>';
					echo'<i>'.$file.'</i>'.'<br>';
				}
				
			}
		}
		?>
		
          
	
</article>
 <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="http:bishopmanjoro.facebook.org"><img src="FWMA_PIC/fb.gif" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="http//:bishopmanjoro.twitter.org">  <img src="FWMA_PIC/twt.gif" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="http//:bishopmanjoro.youtube.org"> <img src="FWMA_PIC/email.gif" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
</body>

</html>