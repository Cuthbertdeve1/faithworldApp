<!DOCTYPE html>
<html lang="en-US">
<head>
<title>videos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />




<!-- jQuery -->
<script type="text/javascript" src="pagesMenu/src/libs/jquery/jquery.js"></script>

<!-- SmartMenus jQuery plugin -->
<script type="text/javascript" src="pagesMenu/jquery.smartmenus.js"></script>


<script type="text/javascript">
	$(function() {
		$('#main-menu').smartmenus({
			subMenusSubOffsetX: 1,
			subMenusSubOffsetY: -8
		});
	});
</script>


<link rel="stylesheet" type="text/css" href="alpages.css">


<link href="pagesMenu/src/css/sm-core-css.css" rel="stylesheet" type="text/css" />

<link href="pagesMenu/src/css/sm-blue/sm-blue.css" rel="stylesheet" type="text/css" />

<link href="pageMenu/src/libs/demo-assets/demo.css" rel="stylesheet" type="text/css" />
<link rel ="stylesheet" type="text/css" href="formzDesign.css">
</head>
<body>
<header width="100%;"height="100%;">
<div id="h_log">
<img id="logo" src="FWMA_PIC/fwm.png"></img>
<div id="h_con">
<h1>Watch</h1>
</div>
</div>
</header>

<nav id="main-nav" role="navigation">
  
  <ul id="main-menu" class="sm sm-blue">
<!--<div id="nav">
  <div id="nav_wrapper">/-->
    
      <li><a href="index.html">Welcome</a></li>
	  
		   <li><a href="bible college.html">Bible College</a></li>
		   <li><a href="itinerary.html">Itinerary</a></li>
		   <li><a href="prayer_request.html">Prayer Request</a></li>
	     
	   <li>
	  
       <a href="about_us.html">About Us</a>
	   <ul>
	       <li><a href="about_bishop.html">Bishop Manjoro</a></li>
		   <li><a href="about_bishop;s family.html">Bishop's Family</a></li>
		   <li><a href="about_work and achivements.html">Work's And Achivements</a></li>
	     </ul>
	   </li><li>
       <a href="audio.html">Audio</a></li>
     </ul>
   <!-- </div>
</div>/-->

</nav>
<br>
		<?php
		$directory="faith world admin potal/videos/video_uploads";
		if($handle = opendir($directory.'/')){
			echo'<b>VIDEOS</b>'.'<br><br>';
			
			while($file = readdir($handle)){
				if($file!='.' && $file!='..'){
					echo'<video  controls width="75%" height="60%" title="'.$file.'" src="'.$directory.'/'.$file.'">'. $file.'
					<source src="'.$directory.'/'.$file.'.mp4"  type="video/mp4">
					<source src="'.$directory.'/'.$file.'.ogv"  type="video/ogg">
					<source src="'.$directory.'/'.$file.'.webm" type="video/webm">
    <object width="640" height="480" type="application/x-shockwave-flash" data="player.swf">
        <param name="movie" value="player.swf">
        <param name="flashvars" value="controlbar=over&amp;image=sample.jpg&amp;file=sample.mp4">
        <img src="sample.jpg" width="640" height="360" alt="Hillsong" >
   title="No direct video playback capabilities, so please download the video below">
    </object>
	
	
					</video><br>';
					echo'<i>'.$file.'</i>'.'<br>';
				}
				
			}
		}
		?>
	

<section>
   
    
  
<article>
   	
	<div id="watch">
	  <div class="vid1">
        <video src="videoz/Desperate People.mp4"controls
             width="600" height="450">
        </video>
		
<figcaption>Desperate People</figcaption>
      </div>
	  <div class="vid1">
        <video src="videoz/Good Good Father.mp4"controls
             width="600" height="450">
        </video>
		
<figcaption>Good Good Father</figcaption>
      </div>
	  <div class="vid1">
        <video controls width="640" height="480" poster="videoz/Hillsong.jpg">
<source src="videoz/Hillsong.mp4"  type="video/mp4">
<source src="videoz/Hillsong.ogv"  type="video/ogg">
<source src="videoz/Hillsong.webm" type="video/webm">
    <object width="640" height="480" type="application/x-shockwave-flash" data="player.swf">
        <param name="movie" value="player.swf">
        <param name="flashvars" value="controlbar=over&amp;image=sample.jpg&amp;file=sample.mp4">
        <img src="sample.jpg" width="640" height="360" alt="Hillsong" 
   title="No direct video playback capabilities, so please download the video below">
    </object>
	
</video>

<figcaption>Hillsong</figcaption>
      </div>
	  <div class="vid1">
        <video width="320" height="240" controls>
		<source that my king src="videoz/My king.mp4" type="video/mp4" id="That My King">
		Your device does not support the video.
            </video>
		
<figcaption>My king</figcaption>
      </div>
	</div>	
			<!-- Start EasyHtml5Video.com BODY section >
<style type="text/css">.easyhtml5video .eh5v_script{display:none}</style>
<div class="easyhtml5video" style="position:relative;max-width:1280px;"><video controls="controls"  autoplay="autoplay" poster="eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.jpg" style="width:100%" title="10,000 Reasons - Unstoppable Love -- Jesus Culture feat Kim Walker-Smith - Jesus Culture Music">
<source src="videoz/eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.m4v" type="video/mp4" />
<source src="videoz/eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.webm" type="video/webm" />
<source src="videeoz/eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.ogv" type="video/ogg" />
<source src="videoz/eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.mp4" />
<object type="application/x-shockwave-flash" data="eh5v.files/html5video/flashfox.swf" width="1280" height="522" style="position:relative;">
<param name="movie" value="eh5v.files/html5video/flashfox.swf" />
<param name="allowFullScreen" value="true" />
<param name="flashVars" value="autoplay=true&controls=true&fullScreenEnabled=true&posterOnEnd=true&loop=false&poster=eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.jpg&src=10%252C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.m4v" />
 <embed src="eh5v.files/html5video/flashfox.swf" width="1280" height="522" style="position:relative;"  flashVars="autoplay=true&controls=true&fullScreenEnabled=true&posterOnEnd=true&loop=false&poster=eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.jpg&src=10%252C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.m4v"	allowFullScreen="true" wmode="transparent" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer_en" />
<img alt="10,000 Reasons - Unstoppable Love -- Jesus Culture feat Kim Walker-Smith - Jesus Culture Music" src="vedioz/eh5v.files/html5video/10%2C000_Reasons_-_Unstoppable_Love_--_Jesus_Culture_feat_Kim_Walker-Smith_-_Jesus_Culture_Music.jpg" style="position:absolute;left:0;" width="100%" title="Video playback is not supported by your browser" />
</object>
</video><div class="eh5v_script"><a href="http://easyhtml5video.com">convert mp4 to webm</a> by EasyHtml5Video.com v3.5</div></div>
<script src="eh5v.files/html5video/html5ext.js" type="text/javascript"></script>
<!-- End EasyHtml5Video.com BODY section -->

		
          
	
</article>
  <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="http:bishopmanjoro.facebook.org"><img src="FWMA_PIC/fb.gif" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="http//:bishopmanjoro.twitter.org">  <img src="FWMA_PIC/twt.gif" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="http//:bishopmanjoro.youtube.org"> <img src="FWMA_PIC/email.gif" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
</body>

</html>